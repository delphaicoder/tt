/*
 * HomeBar — thanh cu chi gia kieu iPhone X, CHI DE TRANG TRI.
 * Nut Home vat ly van la cach chinh de ve Home; thanh nay khong bat ky chuc nang
 * gesture nao (userInteractionEnabled = NO, cham xuyen qua duoc).
 * Hien tren MOI man hinh (Home Screen + trong tung app) qua 1 UIWindow rieng,
 * uu tien vi tri o day man hinh ngang (vi day la thiet ke cho iPad).
 * Bat/tat qua Activator — Activator tu dong them muc vao menu AssistiveTouch
 * cho bat ky listener nao da dang ky, nen khong can tu hook AssistiveTouch rieng.
 */

#import <UIKit/UIKit.h>
#import <libactivator/libactivator.h>

static NSString *const kPrefsPath = @"/var/mobile/Library/Preferences/com.yourname.homebar.plist";
static CFStringRef const kDarwinNotify = CFSTR("com.yourname.homebar/prefschanged");
static NSString *const kActivatorEventName = @"com.yourname.homebar.toggle";

static BOOL gEnabled = YES;
static UIColor *gBarColor;
static CGFloat gBarWidth = 135;
static CGFloat gBarHeight = 5;
static CGFloat gBottomMargin = 8;

static void HB_LoadPrefs(void) {
    NSDictionary *prefs = [NSDictionary dictionaryWithContentsOfFile:kPrefsPath];
    gEnabled = prefs[@"Enabled"] ? [prefs[@"Enabled"] boolValue] : YES;
    NSString *style = prefs[@"Style"]; // "light" (trang) hoac "dark" (den)
    gBarColor = [style isEqualToString:@"dark"]
        ? [UIColor colorWithWhite:0.0 alpha:0.85]
        : [UIColor colorWithWhite:1.0 alpha:0.85];
    if (prefs[@"Width"]) gBarWidth = [prefs[@"Width"] doubleValue];
}

static void HB_SavePrefs(void) {
    NSMutableDictionary *prefs = [NSMutableDictionary dictionaryWithContentsOfFile:kPrefsPath] ?: [NSMutableDictionary dictionary];
    prefs[@"Enabled"] = @(gEnabled);
    [prefs writeToFile:kPrefsPath atomically:YES];
}

// Window rieng chi de hien thanh — cham xuyen qua duoc, khong can UIViewController.
@interface HBIndicatorWindow : UIWindow
@end

static UIView *gPillView;

static void HB_UpdateFrame(HBIndicatorWindow *win) {
    if (!win || !gPillView) return;
    CGRect b = win.bounds;
    // Uu tien layout kieu "ngang": pill luon nam giua theo chieu rong hien tai,
    // sat day man hinh — tu dong dung cho ca ngang lan doc vi chi phu thuoc bounds.
    CGFloat w = MIN(gBarWidth, b.size.width * 0.5);
    CGFloat h = gBarHeight;
    gPillView.frame = CGRectMake((b.size.width - w) / 2.0,
                                  b.size.height - h - gBottomMargin,
                                  w, h);
    gPillView.layer.cornerRadius = h / 2.0;
    gPillView.backgroundColor = gBarColor;
    win.hidden = !gEnabled;
}

@implementation HBIndicatorWindow
- (void)layoutSubviews {
    [super layoutSubviews];
    HB_UpdateFrame(self);
}
- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {
    return NO; // luon cho cham xuyen qua, khong bao gio chan tuong tac
}
@end

static HBIndicatorWindow *gOverlayWindow;

static void HB_EnsureOverlay(void) {
    if (gOverlayWindow) { HB_UpdateFrame(gOverlayWindow); return; }

    HBIndicatorWindow *win = nil;
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if ([scene isKindOfClass:[UIWindowScene class]]) {
                win = [[HBIndicatorWindow alloc] initWithWindowScene:(UIWindowScene *)scene];
                break;
            }
        }
    }
    if (!win) {
        win = [[HBIndicatorWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    }
    win.windowLevel = UIWindowLevelStatusBar + 1000;
    win.backgroundColor = [UIColor clearColor];
    win.userInteractionEnabled = NO;
    win.rootViewController = [UIViewController new];
    win.rootViewController.view.backgroundColor = [UIColor clearColor];
    win.rootViewController.view.userInteractionEnabled = NO;
    win.hidden = NO;

    gPillView = [[UIView alloc] init];
    gPillView.userInteractionEnabled = NO;
    gPillView.layer.masksToBounds = YES;
    [win.rootViewController.view addSubview:gPillView];

    gOverlayWindow = win;
    HB_UpdateFrame(win);
}

static void HB_NotifyCallback(CFNotificationCenterRef c, void *o, CFStringRef n, const void *obj, CFDictionaryRef info) {
    HB_LoadPrefs();
    HB_UpdateFrame(gOverlayWindow);
}

// Dam bao overlay duoc tao/cap nhat ngay khi co window nao tro thanh key trong process nay.
%hook UIWindow
- (void)becomeKeyWindow {
    %orig;
    if ([self isKindOfClass:[HBIndicatorWindow class]]) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        HB_EnsureOverlay();
    });
}
%end

// Activator listener — chi dang ky trong SpringBoard (Activator la he thong dung chung,
// khong can dang ky lai trong tung app). Nguoi dung gan gesture nay (vd AssistiveTouch)
// trong app Activator hoac trong Cai dat > Activator sau khi cai.
@interface HBActivatorListener : NSObject <LAListener>
@end
@implementation HBActivatorListener
- (void)activator:(LAActivator *)activator receiveEvent:(LAEvent *)event {
    gEnabled = !gEnabled;
    HB_SavePrefs();
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                          kDarwinNotify, NULL, NULL, YES);
    HB_UpdateFrame(gOverlayWindow);
    [event setHandled:YES];
}
@end

%ctor {
    HB_LoadPrefs();
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
                                     HB_NotifyCallback, kDarwinNotify, NULL,
                                     CFNotificationSuspensionBehaviorCoalesce);

    NSString *bundleID = [[NSBundle mainBundle] bundleIdentifier];
    if ([bundleID isEqualToString:@"com.apple.springboard"]) {
        [[LAActivator sharedInstance] registerListener:[HBActivatorListener new]
                                                forName:kActivatorEventName];
    }

    %init;
}
