# HomeBar — Thanh cu chi gia kieu iPhone X cho iPad (jailbreak)

**Chi de trang tri** — nut Home vat ly van la cach chinh de ve Home. Thanh nay
khong lam gesture nao ca, chi hien thi, cham xuyen qua duoc (khong chan tuong tac).

- Hien tren **moi man hinh**: Home Screen va trong tung app (inject vao moi
  UIApplication qua filter `Classes = (UIApplication)`).
- Tu dong dat o giua, sat day man hinh — hoat dong ca **ngang lan doc**, uu tien
  layout kieu ngang (thiet ke cho iPad).
- **Bat/tat qua Activator** — sau khi cai, mo app **Activator** (hoac muc
  Activator trong Cai dat) → tim action ten **"HomeBar Toggle"** (hoac tim theo
  bundle id `com.yourname.homebar.toggle`) → gan vao bat ky gesture nao ban
  muon, bao gom **AssistiveTouch** (Activator tu dong ho tro gan vao menu
  AssistiveTouch cho moi listener da dang ky — day la ly do dung Activator thay
  vi tu lam rieng, on dinh hon nhieu so voi hook thang vao AssistiveTouch).

## Cau truc project
```
HomeBar/
├── control
├── Makefile
├── HomeBar.plist      # filter: inject vao moi app (khong chi SpringBoard)
├── Tweak.x             # toan bo logic (khong can Swift/Metal)
└── .github/workflows/build.yml   # build tren Linux (Ubuntu), khong can macOS
```

## Build
Push code len GitHub, tab Actions se tu build tren Ubuntu runner (mien phi),
tai file `.deb` o muc Artifacts — dung y het quy trinh da dung cho cac tweak
truoc, khong can macOS lan nay vi khong dung Metal.

Neu muon tu build tren may/Termux/macOS:
```bash
export THEOS=/path/to/theos
cd HomeBar
make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=rootless
```

## Cai qua Sileo
Can cai **Activator** truoc (hoac de Sileo tu cai vi day la `Depends` trong
control). Sau khi cai HomeBar, mo Activator de gan gesture bat/tat.

## Tuy chinh
Sua cac hang so dau file `Tweak.x` neu muon doi mau/kich thuoc mac dinh:
```objc
static CGFloat gBarWidth = 135;   // do rong pill (pt)
static CGFloat gBarHeight = 5;    // do day pill (pt)
static CGFloat gBottomMargin = 8; // khoang cach tu day man hinh (pt)
```
Mau sac doc tu file prefs `/var/mobile/Library/Preferences/com.yourname.homebar.plist`,
key `Style` = `"light"` (trang, mac dinh) hoac `"dark"` (den). Chua co man hinh
Cai dat rieng — neu ban muon them, bao minh, mo rong tu day khong kho.

## Luu y
- Day la tweak UIKit thuan tuy (khong Swift/Metal) nen build lai duoc tren Linux
  binh thuong, khong dinh cac van de SDK/toolchain phuc tap nhu tweak
  LiquidFolder truoc do.
- Chua test tren thiet bi that — neu window overlay khong hien dung vi tri o
  mot so app dung Split View/Slide Over/Stage Manager tren iPad, day la truong
  hop can tinh chinh them (logic hien tai lay theo `bounds` cua window overlay,
  co the can doi sang lay theo `windowScene.screen.bounds` cho chinh xac hon
  trong che do multitasking).
